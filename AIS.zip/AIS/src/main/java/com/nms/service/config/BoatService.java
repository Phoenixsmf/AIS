package com.nms.service.config;

import java.util.Map;

import com.nms.model.config.Boat;
import com.nms.serialport.utils.Msg;

/**
* @author 作者SMF:
* @version 创建时间：2019年4月16日 下午3:44:42
* 类说明
*/
public interface BoatService {
	Msg deleteByPrimaryKey(String id);

   Msg insert(Boat record);

   int insertSelective(Boat record);

   Boat selectByPrimaryKey(String id);

   Msg selectBoatAll();
   
   Msg updateByPrimaryKeySelective(Boat record);

   int updateByPrimaryKey(Boat record);

	Msg selectBoatAll (Map<String, Object> map);
}
