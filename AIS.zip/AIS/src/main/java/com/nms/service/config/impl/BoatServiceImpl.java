package com.nms.service.config.impl;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nms.dao.config.BoatMapper;
import com.nms.model.config.Boat;
import com.nms.serialport.utils.MiscUtil;
import com.nms.serialport.utils.Msg;
import com.nms.service.config.BoatService;

/**
* @author 作者SMF:
* @version 创建时间：2019年4月16日 下午3:45:01
* 类说明
*/
@Service
//@Transactional
public class BoatServiceImpl implements BoatService{
	@Resource BoatMapper boatmapper;

	@Override
	public Msg insert (Boat record) {
		Date createTime = new Date(new java.util.Date().getTime());
		record.setCreateTime(MiscUtil.dateformat.format(createTime));
		Boat boat = boatmapper.selectByIMSI(record.getImsiId());
		Msg msg = new Msg();
		if(boat!=null){
		msg.setMsg("repeat");
		} else {
			int result = boatmapper.insert(record);	
			if(result == 0){
				msg.setMsg("error");
			}else {
				msg.setMsg("success");
			}
		}
		return msg;
	}

	@Override
	public int insertSelective (Boat record) {
		return boatmapper.insertSelective(record);
	}

	@Override
	public Msg updateByPrimaryKeySelective (Boat record) {
		Date updateTime = new Date(new java.util.Date().getTime());
		Boat boat = boatmapper.selectByIMSI(record.getImsiId());
		Msg msg = new Msg();
		if(boat==null){
			record.setUpdateTime(MiscUtil.dateformat.format(updateTime)); 
			int result = boatmapper.updateByPrimaryKeySelective(record);
			if(result == 0){
				msg.setMsg("error");
				return msg;	
			}
			msg.setMsg("success");
		} else {
			if(boat.getId().equals(record.getId())){
				record.setUpdateTime(MiscUtil.dateformat.format(updateTime)); 
				int result = boatmapper.updateByPrimaryKeySelective(record);
				if(result == 0){
					msg.setMsg("error");
					return msg;	
				}
				msg.setMsg("success");
			}else{
				msg.setMsg("repeat");
			}		
		}
		return msg;
	}

	@Override
	public int updateByPrimaryKey (Boat record) {
		// TODO Auto-generated method stub
		record.setUpdateTime(MiscUtil.dateformat.format(new java.util.Date()));
		return boatmapper.updateByPrimaryKey(record);
	}

	@Override
	public Msg deleteByPrimaryKey (String id) {
		Boat boat = boatmapper.selectByPrimaryKey(id);
		boat.setStatus("3");
		int result = boatmapper.updateByPrimaryKey(boat);
		Msg msg = new Msg();
		if(result == 0){
			msg.setMsg("error");
		}else {
		    msg.setMsg("success");
		}
		return msg;
	}

	@Override
	public Boat selectByPrimaryKey (String id) {
		// TODO Auto-generated method stub
		return boatmapper.selectByPrimaryKey(id);
	}

	@Override
	public Msg selectBoatAll (Map<String ,Object> map) {
		// TODO Auto-generated method stub
		List<Boat> boatList = boatmapper.selectBoatAll(map);
		Msg msg =new Msg();
		if(boatList!=null){
			msg.add(boatList);
			msg.setCount(boatList.size());
		};
		msg.setMsg("success");
		return msg;
	}

	@Override
	public Msg selectBoatAll () {
		// TODO Auto-generated method stub
		return null;
	}

}
