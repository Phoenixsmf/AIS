package com.nms.serialport.utils;

import java.util.List;
/**通用返回信息处理类*/
public class Msg {
	/**状态码 ：0成功，1失败*/
	private int code;
	/**提示信息*/
	private String msg;
	/**数据的数量*/
	private int count;
	private List data;
	
	/**要返回给浏览器的数据*/
	//private Map<String, Object> data = new HashMap<String, Object>();
	/**处理成功*/
	public static  Msg success(){
		Msg result = new Msg();
		result.setCode(0);
		result.setMsg("处理成功");
		return result;			
	}
	/**处理失败*/
	public static  Msg fail(){
		Msg result = new Msg();
		result.setCode(1);
		result.setMsg("处理失败");
		return result;		
	}
	/**添加数据String key,Object value*/
	public Msg add(List data){
		this.setData(data);
		return this;
	}
	public int getCode () {
		return code;
	}
	public void setCode (int code) {
		this.code = code;
	}
	public String getMsg () {
		return msg;
	}
	public void setMsg (String msg) {
		this.msg = msg;
	}
	/*public Map<String, Object> getData () {
		return data;
	}
	public void setData (Map<String, Object> data) {
		this.data = data;
	}*/
	
	public int getCount () {
		return count;
	}
	public List getData () {
		return data;
	}
	public void setData (List data) {
		this.data = data;
	}
	public void setCount (int count) {
		this.count = count;
	}
	
}
