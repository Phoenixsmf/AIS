package com.nms.serialport.utils;

import org.apache.log4j.Logger;
/**
 * 日志处理类
 * @author 耿建成
 *
 */
public final class AISLog
{
	
	private static Logger log = Logger.getLogger(Object.class);
	
	/**
	 * 调试输出
	 * @param myClass
	 * @param message
	 */
	public static void logDebug(Class<?> myClass, String message) {
		log.debug(myClass.getName() + ": " + message);
		////JButtonTest.addText("告警",myClass.getName() + ": " + message);
	}
	
	
	/**
	 * 一般输出
	 * @param myClass
	 * @param message
	 */
	public static void logInfo(Class<?> myClass, String message) {
		log.info(" "+myClass.getName() + ": " + message);
		//JButtonTest.addText("一般",myClass.getName() + ": " + message);
	}
	
	
	/**
	 * 警告输出
	 * @param myClass
	 * @param message
	 */
	public static void logWarn(Class<?> myClass, String message) {
		log.warn(" "+myClass.getName() + ": " + message);
	}
	
	
	/**
	 * 错误输出
	 * @param myClass
	 * @param message
	 */
	public static void logError(Class<?> myClass, String message) {
		log.error(myClass.getName() + ": " + message);
	}
	
	
	/**
	 * 错误输出
	 * @param myClass
	 * @param message
	 */
	public static void logError(String className, String message) {
		log.error( " " + message);
	}
	
	
	/**
	 * 致命输出
	 * @param myClass
	 * @param message
	 */
	public static void logFatal(Class<?> myClass, String message) {
		log.fatal(myClass.getName() + ": " + message);
	}
	
	

	
	/**
	 * 进入方法日志
	 * @param myClass 类
	 * @param method 方法
	 */
	public static void logEnterMethod(Class<?> myClass,String method){
		logInfo(myClass, "entry method " + method);
	}
	
	/**
	 * 走出方法日志
	 * @param myClass 类
	 * @param method 方法
	 */
	public static void logExitMethod(Class<?> myClass,String method){
		logInfo(myClass, "exit  method " + method);
	}
	
	
	/**
	 * 打印异常
	 * @param myClass
	 * @param e
	 * @param method
	 */
	public static void logCatch(Class myClass, Exception e, String method) {
		error(myClass, "caught exception while trying to " + method + ": " + e);
		//JButtonTest.addText("错误",myClass.getName() + ": " + "caught exception while trying to " + method + ": " + e);
	}
	public static void error(Class myClass, String message) {
		log.error(myClass.getName() + ": " + message);
		//log.error(message);
	}

 
	
 
}



