package com.nms.serialport.utils;

import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class MiscUtil {
		
	public static SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static SimpleDateFormat dateformat_ymd = new SimpleDateFormat("yyyy-MM-dd");
	private static DocumentBuilder builder = null;
	private static DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	private static Document document;
	private static NodeList itemNodes;
	

	/**
	 * 获取UUID
	* @Title: getUUID   
	* @Description: 获取32位的uuid   
	* @param: @return      
	* @return: String      
	* @throws  
	* @date 2018年2月28日 上午9:26:11
	 */
	public static String getUUID(){
		
		return UUID.randomUUID().toString().replaceAll("-", "");
		
	}
	
	/**
	 * Object对象转换成yyyy-MM-dd HH:mm:ss格式的字符串
	 * @param date
	 * @return
	 */
	public static Date toStr(Object date) throws Exception{
		if(date==null){
			return null;
		}
		Date str = dateformat.parse(date.toString());
		return str;
	}
	
	/**
	 * 将 date 类型 转换格式为 ：yyyy-MM-dd 的日期 字符串
	 * @param date
	 * @return
	 */
	public static String parseDateToStr_ymd(Object date) {
		String str = dateformat_ymd.format(date);
		return str;
	}
	
	/**
	 * yyyy-MM-dd HH:mm:ss格式的字符串转换成Date对象
	 * @param date
	 * @return
	 * @throws ParseException 
	 */
	public static Date toDate(String str) throws ParseException {
		if (str == null || "".equals(str.trim())) {
			return null;
		}
		Date date = dateformat.parse(str);
		return date;
	}
	
	/**
	 * Str 转换  yyyy-MM-dd HH:mm:ss格式的Date对象
	 * @param str
	 * @return
	 */
	public static Date parseStrToDate(String str) {
		Date date = null;
		if (str == null || "".equals(str.trim())) {
			return date;
		}
		try {
			date = dateformat.parse(str);
		} catch (ParseException e) {
			return date;
		}
		return date;
	}
	
	
	
	
	public static int parseSecretFileXMLResult(String xml) throws Exception {
		if(builder == null) {
			builder = factory.newDocumentBuilder();
		}
		StringReader input = new StringReader(xml);
		InputSource is = new InputSource(input);
		is.setEncoding("utf-8");
		document = builder.parse(is);
		document.normalize();
		itemNodes = document.getElementsByTagName("response");
		Element eventsElement = (Element)itemNodes.item(0);
		if (eventsElement != null) {
			NodeList modeNodes = eventsElement.getElementsByTagName("result");
			return Integer.parseInt(modeNodes.item(0).getFirstChild().getNodeValue());
		}
		return 0;
	}
	
	
	
	
	private static String oldId = null;
	private static int num;
	
	/**
	 * 依据年月日时分秒创建id号，如果产生相同id，则会在新id按顺序新增自然数
	 * 
	 * @return 日期时间相连的字符串
	 */
	public synchronized static String createNewId() {
		if (num == 9999) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
		}
		Calendar rightNow  = Calendar.getInstance();
		int m = rightNow.get(Calendar.MONDAY) + 1;
		int d = rightNow.get(Calendar.DATE);
		int h = rightNow.get(Calendar.HOUR_OF_DAY);
		int mi = rightNow.get(Calendar.MINUTE);
		int s = rightNow.get(Calendar.SECOND);
		StringBuffer sb = new StringBuffer();
		sb.append(rightNow.get(Calendar.YEAR));
		if (m < 10) {
			sb.append("0");
		}
		sb.append(m);
		if (d < 10) {
			sb.append("0");
		}
		sb.append(d);
		if (h < 10) {
			sb.append("0");
		}
		sb.append(h);
		if (mi < 10) {
			sb.append("0");
		}
		sb.append(mi);
		if (s < 10) {
			sb.append("0");
		}
		sb.append(s);
		String newId = sb.toString();
		if (newId.equals(oldId)) {
			newId += (++num);
		} else {
			num = 0;
		}
		oldId = sb.toString();
		return newId;
	}
	
	
	/**
	 * 创建稳定的，定长的数字id号 <br>
	 * 该方法返回 19位长度字符串 <br>
	 * 
	 * @return
	 */
	public synchronized static String createStableId() {
		final int size =18; //18位数字
		StringBuffer sb =new StringBuffer(createNewId());
		int len =sb.length(); //最少14位
		int diff =size-len;
		
		if (diff == 4) {
			sb.append("0"+Math.round(Math.random()*(9999-1000) + 1000)); //补充四位[1000-9999]随机数字
		}else if(diff==3){
			sb.append("0"+Math.round(Math.random()*(999-100) + 100)); //补充三位[100-999]随机数字
		}else if(diff==2){
			sb.append("0"+Math.round(Math.random()*(99-10) + 10)); //补充二位[10-99]随机数字
		}else if(diff==1){
			sb.append("0"+Math.round(Math.random()*(9-0) + 0)); //补充一位[0-9]随机数字
		} else if (diff == 0) {
			sb.insert(0, "0"); // 前位补 0
		}
		return sb.toString();
	}
	
	/**
	 * 创建随机的0-9，A-Z字符串
	 * @param length
	 * @return
	 */
	public static String createRandomStr(int length){
		String allChar="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuffer sb =new StringBuffer();
		Random random = new Random();
		for(int i=0;i<length;i++){
			sb.append(allChar.charAt(random.nextInt(allChar.length())));
		}
		return sb.toString();
	}
	/**
	 * 创建随机的0-9，A-F字符串
	 * @param length
	 * @return
	 */
	public static String createRandomStr2(int length){
		String allChar="0123456789ABCDEF";
		StringBuffer sb =new StringBuffer();
		Random random = new Random();
		for(int i=0;i<length;i++){
			sb.append(allChar.charAt(random.nextInt(allChar.length())));
		}
		return sb.toString();
	}
	
	/**
	 * 获取请求客户端的ip地址
	* @Title: getIpAddr   
	* @Description: TODO(这里用一句话描述这个方法的作用)   
 	* @param: @return      
	* @return: String      
	* @throws  
	* @date 2017年11月27日 上午10:07:20
	 */
/*	public static String getIpAddr() {
			HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();  
			String ip = request.getHeader("x-forwarded-for");
			if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("Proxy-Client-IP");
			}
			if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("WL-Proxy-Client-IP");
			}
			if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getRemoteAddr();
			}
			return ip;
		} 
	*/
	
			/**
	       * String转换Map
	       * 
	       * @param mapText
	       *            
	       * @return Map<?,?>
	       */
	      public static Map<String, Object> StringToMap(String mapText) {
	    	  String SEP1 = "=";
 	          if (mapText == null || mapText.equals("")||mapText.length()<=2) {
	              return new HashMap();
	          }
	          mapText = mapText.substring(1,mapText.length()-2);
	          Map<String, Object> map = new HashMap<String, Object>();
	          String[] text = mapText.split(","); // 转换为数组
	          for (String str : text) {
	             String[] keyText = str.split(SEP1); // 转换key与value的数组
	             String key = keyText[0].trim(); // key
	             String value = keyText[1].trim(); // value
	             map.put(key, value);
	         }
	        return map;
	     }
}
