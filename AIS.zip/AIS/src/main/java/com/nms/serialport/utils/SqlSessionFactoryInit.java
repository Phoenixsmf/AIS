package com.nms.serialport.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class SqlSessionFactoryInit {

	private static SqlSessionFactory sqlSessionFactory = null;
	private static ApplicationContext context = null;

	public static ApplicationContext getContext() {
		return context;
	}

	public static void creatSqlSessionFactory() {
		String resource = "/config/mybatis-config.xml";
		String props = "/config/jdbc.properties";
		context = new FileSystemXmlApplicationContext("classpath:config/applicationContext.xml");

		// 得到配置文件流
		InputStream inputStream = null;
		InputStream inputStream2 = null;
		try {
			//inputStream = Resources.getResourceAsStream(resource);
			//inputStream2 = Resources.getResourceAsStream(props);
			inputStream = SqlSessionFactoryInit.class.getResourceAsStream(resource);
			inputStream2 = SqlSessionFactoryInit.class.getResourceAsStream(props);
			Properties properties = new Properties();
			properties.load(inputStream2);
			// 创建会话工厂，传入MyBatis的配置信息
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream, properties);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					// e.printStackTrace();
				}
			}
			if (inputStream2 != null) {
				try {
					inputStream2.close();
				} catch (IOException e) {
					//e.printStackTrace();
				}
			}
		}
	}

	public static SqlSessionFactory getSqlSessionFactory() {
		return sqlSessionFactory;
	}

}
