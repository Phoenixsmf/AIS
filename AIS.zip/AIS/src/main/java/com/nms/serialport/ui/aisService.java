package com.nms.serialport.ui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nms.dao.config.BoatMapper;
import com.nms.model.config.Boat;
import com.nms.serialport.utils.SqlSessionFactoryInit;

public class aisService {

	public static void main(String[] args) {
	SqlSessionFactoryInit.creatSqlSessionFactory();
	 BoatMapper boatMapper = SqlSessionFactoryInit.getContext().getBean(BoatMapper.class);
	 Map<String, Object> dataMap = new HashMap<>();
	 dataMap.put("page", 0);
	 dataMap.put("limit", 10);
	List<Boat> boatList = boatMapper.selectBoatAll(dataMap);
	for(Boat boat:boatList){
		System.out.println(boat.getMmsiId());
	}
	}
}
