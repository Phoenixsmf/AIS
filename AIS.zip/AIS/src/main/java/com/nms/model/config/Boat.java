package com.nms.model.config;

public class Boat {
	 private String rownum;
	
    private String id;

    private String imsiId;

    private String mmsiId;

    private String createTime;

    private String updateTime;
    
    private String status;

    private String comment;
    
    private String longitude;

    private String latitude;
    
    private String sog;

    private String cog;
         
    
    public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getRownum () {
		return rownum;
	}

	public void setRownum (String rownum) {
		this.rownum = rownum;
	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
  
    public String getImsiId () {
		return imsiId;
	}

	public void setImsiId (String imsiId) {
		this.imsiId = imsiId;
	}

	public String getMmsiId () {
		return mmsiId;
	}

	public void setMmsiId (String mmsiId) {
		this.mmsiId = mmsiId;
	}

	public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime () {
		return updateTime;
	}

	public void setUpdateTime (String updateTime) {
		this.updateTime = updateTime;
	}

	public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment == null ? null : comment.trim();
    }

	public String getSog() {
		return sog;
	}

	public void setSog(String sog) {
		this.sog = sog;
	}

	public String getCog() {
		return cog;
	}

	public void setCog(String cog) {
		this.cog = cog;
	}
    
    
}