package com.nms.dao.config;

import java.util.List;
import java.util.Map;

import com.nms.model.config.Boat;


public interface BoatMapper {
    int deleteByPrimaryKey(String id);

    int insert(Boat record);

    int insertSelective(Boat record);

    List<Boat> selectBoatAll(Map<String, Object> map);
    
    List<Boat> getAllBoat();
    
    Boat selectByPrimaryKey(String id);

    Boat selectByIMSI(String imsi);
    
    Boat selectByMMSI(String mmsi);
    
    int updateByPrimaryKeySelective(Boat record);

    int updateByPrimaryKey(Boat record);
}