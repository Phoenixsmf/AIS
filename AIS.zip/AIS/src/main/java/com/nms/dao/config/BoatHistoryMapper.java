package com.nms.dao.config;

import java.util.List;
import java.util.Map;

import com.nms.model.config.Boat;


public interface BoatHistoryMapper {
    int deleteByPrimaryKey(String id);

    int insert(Boat record);

    int insertSelective(Boat record);

    List<Boat> selectBoatAll(Map<String, Object> map);
    
    Boat selectByPrimaryKey(String id);

    Boat selectByIMSI(String imsi);
    
    int updateByPrimaryKeySelective(Boat record);

    int updateByPrimaryKey(Boat record);
}